require('dotenv').config();
const { Client, IntentsBitField, EmbedBuilder, Embed, ActivityType } = require('discord.js');

const client = new Client({
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent,
    ],
});

client.on('ready', (c) => {
    console.log(`✔️  ${c.user.username} is online!`);
});

client.on('interactionCreate', async (interaction) => {
    //Self give role interactions.
    try {
        if(!interaction.isButton()) return;
        await interaction.deferReply({ ephemeral: true });
    
        const role = interaction.guild.roles.cache.get(interaction.customId);
        if(!role){
            interaction.editReply({
                content: 'Role not found.',
            });
            return;
        }
    
        const hasRole = interaction.member.roles.cache.has(role.id);
    
        if(hasRole){
            await interaction.member.roles.remove(role);
            await interaction.editReply(`The role ${role} has been removed.`);
            return;
        }
    
        await interaction.member.roles.add(role);
        await interaction.editReply(`The role ${role} has been added.`);
       } catch (error) {
        console.log(error);
       }

    //Introduces itself in a joking manner. 
    if(!interaction.isChatInputCommand()) return;

    if(interaction.commandName === 'joke'){
        interaction.reply("Why am I called 'takobot'? I don't wanna takobout it.");
    }

    //Searches for help with races or classes.
    if(interaction.commandName === 'help'){
        const creatureRace = interaction.options.get('race')?.value;
        const creatureClass = interaction.options.get('class')?.value;
        
        //Races in alphabetical order. 
        if(creatureRace === 'elf'){
            const embed = new EmbedBuilder()
                .setTitle("Elf Information")
                .setDescription("Description for elves.")
                .setColor(0xb6dbad)
                .setThumbnail('https://i.imgur.com/UOpV5eB.png')
                .addFields({
                    name: 'Field Title',
                    value: 'Field Value',
                    inline: false,
                }, {
                    name: 'Second Field Title',
                    value: 'Field Value',
                    inline: false,
                })
                .setImage('https://i.imgur.com/00JFEVi.jpg')
                .setTimestamp();

            interaction.reply({ embeds: [ embed ] });
        }
        if(creatureRace === 'human'){
            const embed = new EmbedBuilder()
                .setTitle("Human Information")
                .setDescription("Description for humans.")
                .setColor(0xffffff)
                .setThumbnail('https://i.imgur.com/rR19gD1.jpg')
                .addFields({
                    name: 'Field Title',
                    value: 'Field Value',
                    inline: false,
                }, {
                    name: 'Second Field Title',
                    value: 'Field Value',
                    inline: false,
                })
                .setImage('https://i.imgur.com/eNi2voV.png')
                .setTimestamp();

            interaction.reply({ embeds: [ embed ] });
        } 

        //Classes in alphabetical order. 
        if(creatureClass === 'fighter'){
            const embed = new EmbedBuilder()
                .setTitle("Fighter Information")
                .setDescription("Description for fighters.")
                .setColor(0xc23c32)
                .setThumbnail('https://i.imgur.com/TEKcNXe.png')
                .addFields({
                    name: 'Field Title',
                    value: 'Field Value',
                    inline: false,
                }, {
                    name: 'Second Field Title',
                    value: 'Field Value',
                    inline: false,
                })
                .setImage('https://i.imgur.com/6ZZ3y2O.jpg')
                .setTimestamp();

            interaction.reply({ embeds: [ embed ] });
        }
        if(creatureClass === 'sorcerer'){
            const embed = new EmbedBuilder()
                .setTitle("Sorcerer Information")
                .setDescription("Description for sorcerers.")
                .setColor(0x0e1663)
                .setThumbnail('https://i.imgur.com/qKPIFKS.png')
                .addFields({
                    name: 'Field Title',
                    value: 'Field Value',
                    inline: false,
                }, {
                    name: 'Second Field Title',
                    value: 'Field Value',
                    inline: false,
                })
                .setImage('https://i.imgur.com/aTdXR8L.jpg')
                .setTimestamp();

            interaction.reply({ embeds: [ embed ] });
        }

        console.log(creatureRace);
        console.log(creatureClass);
    }
});

client.login(process.env.TOKEN);