require('dotenv').config();
const { Client, IntentsBitField, EmbedBuilder, Embed, ActivityType, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

const client = new Client({
    intents: [
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent,
    ],
});

const roles = [
    {
        id: '1186103037941534810',
        label: 'Player',
    },
    {
        id: '1186118880758866020',
        label: 'TBD1',
    },
    {
        id: '1186118920944492725',
        label: 'TBD2',
    },
    {
        id: '1186118937474248714',
        label: 'TBD3',
    },
]

client.on('ready', async (c) => {
try {
    const channel = await client.channels.cache.get('1186119051693523074');
    if(!channel) return;

    const row = new ActionRowBuilder();

    roles.forEach((role) => {
        row.components.push(
            new ButtonBuilder()
                .setCustomId(role.id)
                .setLabel(role.label)
                .setStyle(ButtonStyle.Primary)
        );
    });

    await channel.send({
        content: "Click a button to gain a role according to the button's name. Anyone can be assigned the @player role, however please only give it to yourself when you have have started at least one campaign. To assign a campaign role, you must have the @player role first. You also cannot join a campaign without the appropriate character role, so ping @tennshii to get a character role. To remove a role, click the button again.",
        components: [row],
    });
    process.exit();
} catch (error) {
    console.log(error);
}

    console.log(`✔️  ${c.user.username} is online!`);
});

client.login(process.env.TOKEN);